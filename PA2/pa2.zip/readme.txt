We chose to use JavaScript as our language for PA2, as its weak, dynamic typing
makes it difficult to work with in other (more complicated) projects in this
class (recall that we cannot repeat languages, so we're saving the good ones for
later). We used jison as the lexical analyzer generator as was suggested in the
problem statement. The format of the jison file had a regex on the left side of
a line and JavaScript code to execute when that expression was matched on the
right side. A simple context-free grammar was also specified so that code
generation ran smoothly -- we did not use the parser, but jison expected a
grammar to be written.

The singleton tokens were recognized with regular expressions of the form
[iI][fF] to get the case insensitive behavior as defined in the reference
manual. The word boundary metacharacter \b was helpful in separating out
keywords from identifiers that happened to contain keywords (like "iff").
Identifiers, types, integer constants, and whitespace were recognized with
simple regular expressions matching their definitions in the reference manual.
However, integers had extra code to check that they were within the range of a
signed 32 bit int, and the newline character was recognized separately from the
other whitespace characters to properly increment the line counter.

Comments and string constants were recognized using a combination of regular
expressions and jison's state system. Single line comments simply used the state
system to ignore input until the end of the line. Multiline comments made
greater use of the state system to implement the nested comment behavior. Each
time a "(*" was read, we added another multiline comment state to the stack, and
once in a multiline comment state we ignored all text until we read a *, (, or
). Using the maximal munch rule we ignored the lone parentheses and stars and
popped a state off the stack if we read a "*)". Strings used the state system to
add extra logic to append the literal between the quotes to a string buffer,
with special logic for the \" rule and errors for newlines and the end of file
mark, and a final check on length at the end of the string.

We tested as we wrote our lexer with a file containing simple tokens, both
positive and negative. This approach ensured that we caught all simple bugs
early on. After finishing our first iteration, we tested on sample Cool code
provided to us, comparing our results against the reference compiler's. We also
used wrote auxiliary scripts to generate and process test files. Afterwards, we
did a back and forth of submitting our code to the server and looking over our
code again to catch errors. Most of our problems arose from flawed comment and
string state management, as well as incorrect line number counts. Testing on
random characters was also somewhat helpful -- we found that the reference
compiler treated the character with integer value 0x1A ("substitute" says
Google) as EOF, so we added some checks in so that it produced the same
behavior.

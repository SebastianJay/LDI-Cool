from TAC_serialize import *
from TAC_serialize import _constructCFG
from registerAllocate import registerAllocate
import sys
from deadcode import globalDeadRemove
from dataflow import optCFG

#if a different width of a register is needed find the label in this mapping
regWidthMap = {
    '%rax' : ['%rax', '%eax', '%ax', '%al'],
    '%rbx' : ['%rbx', '%ebx', '%bx', '%bl'],
    '%rcx' : ['%rcx', '%ecx', '%cx', '%cl'],
    '%rdx' : ['%rdx', '%edx', '%dx', '%dl'],
    '%rsi' : ['%rsi', '%esi', '%si', '%sil'],
    '%rdi' : ['%rdi', '%edi', '%di', '%dil'],
    '%rbp' : ['%rbp', '%ebp', '%bp', '%bpl'],
    '%rsp' : ['%rsp', '%esp', '%sp', '%spl'],
    '%r8' : ['%r8', '%r8d', '%r8w', '%r8b'],
    '%r9' : ['%r9', '%r9d', '%r9w', '%r9b'],
    '%r10' : ['%r10', '%r10d', '%r10w', '%r10b'],
    '%r11' : ['%r11', '%r11d', '%r11w', '%r11b'],
    '%r12' : ['%r12', '%r12d', '%r12w', '%r12b'],
    '%r13' : ['%r13', '%r13d', '%r13w', '%r13b'],
    '%r14' : ['%r14', '%r14d', '%r14w', '%r14b'],
    '%r15' : ['%r15', '%r15d', '%r15w', '%r15b'],
}

#maps int result of graph coloring to x64 register name
cRegMap = {
    0 : '%rax',     #return value for function calls
    1 : '%rdi',
    2 : '%rsi',
    3 : '%rdx',
    4 : '%rcx',
    5 : '%r8',      #64 bit mode registers
    6 : '%r9',
    7 : '%r10',
    8 : '%r11',
    9 : '%rbx',
    10 : '%r12',
    11 : '%r13',
    12 : '%r14',
    13 : '%r15',
}
rsp = '%rsp'
rbp = '%rbp'
retreg = 0
paramRegs = [1,2,3,4,5,6,7,8]

registers = cRegMap.values() + [rsp, rbp]

#static class that turns cmap, imap, and pmap into offset and label mappings
class ASMIndexer:
    #string class => int class tag
    #make sure initial mapping is consistent with internals.c constants
    clsTags = {
        'Object' : 0,
        'Int' : 1,
        'String' : 2,
        'IO' : 3,
        'Bool' : 4,
    }

    #string class => int size of object of class (number of named attributes)
    objSize = {
        'Object' : 0,
        'Bool' : 1,     #0 or 1 value
        'Int' : 1,      #int value
        'IO' : 0,
        'String' : 1,   #ptr to string
    }

    #string class => list of string labels
    vtableMap = {
        'Object' : ['name_Object', '0', 'Object.new', 'Object.abort', 'Object.copy', 'Object.type_name'],
        'Bool' : ['name_Bool', '1', 'Bool.new', 'Object.abort', 'Object.copy', 'Object.type_name'],
        'Int' : ['name_Int', '1', 'Int.new', 'Object.abort', 'Object.copy', 'Object.type_name'],
        'IO' : ['name_IO', '0','IO.new', 'Object.abort', 'Object.copy', 'Object.type_name', \
            'IO.in_int', 'IO.in_string', 'IO.out_int', 'IO.out_string'],
        'String' : ['name_String', '2','String.new', 'Object.abort', 'Object.copy', 'Object.type_name', \
            'String.concat', 'String.length', 'String.substr'],
    }

    #string literal => string label where literal stored
    strMap = {
        'Object' : 'name_Object',
        'Bool' : 'name_Bool',
        'Int' : 'name_Int',
        'IO' : 'name_IO',
        'String' : 'name_String',
        '' : 'empty_string',
        'abort\\\\n' : 'abort_string',
        'ERROR: %lld: Exception: String index out of bounds' : 'substrerr_string',
        '%d' : 'percentd_string',
        '%lld' : 'percentlld_string',
        '%s' : 'percents_string'
    }

    #string runtime error id => string literal
    errstrMap = {
        'casevoid' : 'ERROR: %lld: Exception: case on void\\n',
        'casenomatch' : 'ERROR: %lld: Exception: case without matching branch\\n',
        'dispatchvoid' : 'ERROR: %lld: Exception: dispatch on void\\n',
        'stackoverflow' : 'ERROR: %lld: Exception: stack overflow\\n',
        'dividezero' : 'ERROR: %lld: Exception: division by zero\\n',
        #substring error handled internally
    }

    attrOffset = {}     #string class => (string attribute => int index of attr)
    methOffset = {}     #string class => (string method => (string formal => int index of formal))
    vtableOffset = {}   #string class => (string method => int index of method in table)

    #the map definitions are the unboxed definitions provided in annast.py
    @staticmethod
    def load(cmap, imap, pmap, inslist):
        #create clsTags
        tagind = 10
        for cname in cmap:
            if cname in ASMIndexer.clsTags:
                continue
            ASMIndexer.clsTags[cname] = tagind
            tagind += 1

        #create objSize
        for cname in cmap:
            if cname in ASMIndexer.objSize:
                continue
            #number of attributes, excluding 3 extra for every class (class tag, vtable pointer, obj size)
            ASMIndexer.objSize[cname] = len(cmap[cname])

        #create strMap
        #create type name strings
        strind = 0
        for cname in cmap:
            if cname in ASMIndexer.strMap:
                continue
            ASMIndexer.strMap[cname] = '.string' + str(strind)
            strind += 1
        #add runtime error strings
        for literal in ASMIndexer.errstrMap.values():
            if literal in ASMIndexer.strMap:
                continue
            ASMIndexer.strMap[literal] = '.string' + str(strind)
            strind += 1

        # Have to escape backslashes and quotes for assembler
        for ins in inslist:
            if isinstance(ins, TACConstant) and ins.ptype == 'string' and ins.const not in ASMIndexer.strMap:
                ins.const = ins.const.replace('\\', '\\\\')
                ins.const = ins.const.replace('\"', '\\\"')

        #add literals found in TAC list
        for ins in inslist:
            if isinstance(ins, TACConstant) and ins.ptype == 'string' and ins.const not in ASMIndexer.strMap:
                ASMIndexer.strMap[ins.const] = '.string' + str(strind)
                strind += 1
        #TODO cull list after optimization to remove unused strings


        #create attrOffset
        for cname in cmap:
            attrmap = {}
            #attr index 0 = vtable pointer
            # other attributes start at index 1
            for i, cattr in enumerate(cmap[cname]):
                attrmap[cattr.name] = i+1
            ASMIndexer.attrOffset[cname] = attrmap

        #create vtableMap
        for i, cname in enumerate(imap):
            if cname in ASMIndexer.vtableMap:
                continue
            #entry 0 of vtable is string of class name
            #entry 1 is number of fields
            #entry 2 is new method
            labels = [ASMIndexer.strMap[cname], str(len(ASMIndexer.attrOffset[cname])), cname + '.new']
            # methods start at index 2 of table
            for imeth in imap[cname]:
                labels.append(imeth.orig + '.' + imeth.name)
            ASMIndexer.vtableMap[cname] = labels

        #create methOffset
        for cname in imap:
            methmap = {}
            for imeth in imap[cname]:
                formmap = {}
                #the implicit first formal is the "self" arg
                formmap['self'] = 0
                #the rest of the arguments start at index 1
                for i, fname in enumerate(imeth.formals):
                    formmap[fname] = i+1
                methmap[imeth.name] = formmap
            ASMIndexer.methOffset[cname] = methmap

        #create vtableOffset
        for cname in imap:
            methmap = {}
            for i, imeth in enumerate(imap[cname]):
                #index 0 of vtable contains type name string
                #index 1 is object size
                #index 2 is constructor
                methmap[imeth.name] = i+3
            ASMIndexer.vtableOffset[cname] = methmap

    @staticmethod
    def getvtableind(cname, methname):
        ind = -1
        for i, meth in enumerate(ASMIndexer.vtableMap[cname]):
            # Skip name string
            if i < 2:
                continue
            if meth.split('.')[1] == methname:
                ind = i
        return 8*ind

    #returns a list of ASMInstruction corresponding to vtables in vtableMap
    @staticmethod
    def genVtable():
        vlist = []
        for c in ASMIndexer.vtableMap:
            vlist.append(ASMLabel(c + '_vtable'))
            for meth in ASMIndexer.vtableMap[c]:
                vlist.append(ASMInfo('quad', meth))

        return vlist

    #returns a list of ASMInstruction corresponding to literals in strMap
    @staticmethod
    def genStr():
        slist = []
        for s in ASMIndexer.strMap:
            slen = len(s.replace('\\\\', '\\').replace('\\\"', '\"'))
            slist += [
                # String literal
                ASMLabel(ASMIndexer.strMap[s]+"_l"),
                ASMInfo('string', '"' + s + '"'),
                # String object
                ASMLabel(ASMIndexer.strMap[s]),
                ASMInfo('quad', 'String_vtable'),
                ASMInfo('quad', ASMIndexer.strMap[s]+"_l"),
                ASMInfo('quad', str(slen))
            ]
        return slist

#begin ASM class definitions - adapted from TAC
# these classes do not necessarily correspond to one x86 instruction apiece
# some may require auxiliary instructions like shifting between registers/stack
# use expand() to get a list of total instructions

#"abstract" class for one ASM instruction
class ASMInstruction:
    def expand(self):
        return [self]

#generic class for ASM instruction which computes an operation
#most instructions will destroy an operand, so to preserve it we need to shift between some registers
class ASMOp(ASMInstruction):
    def __init__(self, assignee, opcode, operands=[]):
        self.assignee = assignee
        self.opcode = opcode
        self.operands = operands
        self.halfreg = False
    def expand(self):
        asm = []

        # If operating on two memory addresses
        if len(self.operands)==2 and not (
            self.operands[0] in registers or self.operands[0][0] == '$'
            or self.operands[1] in registers or self.operands[1][0] == '$'):
            asm.append(ASMAssign('%rdx',self.operands[0]))
            self.operands[0] = '%rdx'

        if self.opcode == 'isvoid':
            return ASMOp(self.assignee, '=', [self.operands[0],'$0']).expand()

        # Bool logic expand
        if self.opcode in ['<', '=', '<=']:
            cmpop1 = self.operands[1]
            if cmpop1 in registers and cmpop1 not in [rsp, rbp]:
                cmpop1 = regWidthMap[cmpop1][1]
            cmpop0 = self.operands[0]
            if cmpop0 in registers and cmpop0 not in [rsp, rbp]:
                cmpop0 = regWidthMap[cmpop0][1]

            asm.append(ASMCmp(cmpop1, cmpop0, True))

        if (len(self.operands) == 1 and self.operands[0] != self.assignee)\
           or (len(self.operands) == 2 and self.operands[1] != self.assignee):
            asm.append(ASMAssign(self.assignee, self.operands[0]))

        if self.opcode == '/':
            asm.append(ASMMisc('cdq'))  #sign extend eax to edx:eax

        #switch to 32 bit registers for arithmetic
        if self.opcode in ['+', '-', '*', '/', '~'] and self.assignee not in [rsp, rbp]:
            if self.operands[0] in registers:
                self.operands[0] = regWidthMap[self.operands[0]][1]
            if self.opcode in ['+', '-'] and self.assignee in registers:
                self.assignee = regWidthMap[self.assignee][1]
            self.halfreg = True

        asm.append(self)
        return asm

    def __str__(self):
        if self.opcode == '+':
            return ('addl ' if self.halfreg else 'addq ') + self.operands[0] + ', ' + self.assignee
        elif self.opcode == '-':
            return ('subl ' if self.halfreg else 'subq ') + self.operands[0] + ', ' + self.assignee
        elif self.opcode == '*':
            return ('imull ' if self.halfreg else 'imulq ') + self.operands[0]
        elif self.opcode == '/':
            return ('idivl ' if self.halfreg else 'idivq ') + self.operands[0]
        elif self.opcode == '<':
            return 'setl ' + regWidthMap[self.assignee][3]
        elif self.opcode == '<=':
            return 'setle ' + regWidthMap[self.assignee][3]
        elif self.opcode == '=':
            return 'sete ' + regWidthMap[self.assignee][3]
        elif self.opcode == 'not':
            return 'xorq $1, ' + self.assignee
        elif self.opcode == 'isvoid':
            pass
        elif self.opcode == '~':
            return ('negl ' if self.halfreg else 'negq ') + self.operands[0]
        elif self.opcode == '&':
            return 'andq ' + self.operands[0] + ', ' + self.assignee
        elif self.opcode == '|':
            return 'orq ' + self.operands[0] + ', ' + self.assignee
        elif self.opcode == '<<':
            return 'shlq ' + self.operands[0] + ', ' + self.assignee
        elif self.opcode == '>>':
            return 'sarq ' + self.operands[0] + ', ' + self.assignee    #arithmetic, so sign is preserved
        return '\n'

#compare two numbers and set appropriate flags for conditional moves/jumps
class ASMCmp(ASMInstruction):
    def __init__(self, op1, op2, halfreg=False, comp=True):
        self.op1 = op1
        self.op2 = op2
        self.halfreg = halfreg
        self.comp = comp
    def __str__(self):
        return ('cmp' if self.comp else 'test')+('l ' if self.halfreg else 'q ') + self.op1 + ', ' + self.op2

#ASM instruction which assigns one variable into another
class ASMAssign(ASMInstruction):
    def __init__(self, assignee, assignor):
        self.assignee = assignee
        self.assignor = assignor
    def expand(self):
        # Memory-memory move fix
        asm = []
        if not (self.assignor in registers or self.assignor[0] == '$' or self.assignee in registers):
            asm.append(ASMAssign('%rdx', self.assignor))
            self.assignor = '%rdx'
        asm.append(self)
        return asm
    def __str__(self):
        return 'movq ' + self.assignor + ', ' + self.assignee

#"abstract" class for TAC instructions which declare variables
class ASMDeclare(ASMInstruction):
    pass

#for 'new' and 'default' instructions
class ASMAllocate(ASMDeclare):
    def __init__(self, assignee, allop, ptype):
        self.assignee = assignee
        self.allop = allop  #should be 'default' or 'new'
        self.ptype = ptype
    def expand(self):
        if self.allop == 'new' or self.ptype == 'Int' or self.ptype == 'Bool' or self.ptype == 'String':
            if self.assignee != '%rax':
                return [ASMPush('%rax'), ASMCall('%rax', self.ptype + '.new'), ASMAssign(self.assignee, '%rax'), ASMPop('%rax')]
            else:
                return [ASMCall('%rax', self.ptype + '.new')]
        else:
            return [self]
    def __str__(self):
        if self.allop == 'new' or self.ptype == 'Int' or self.ptype == 'Bool' or self.ptype == 'String':
            return 'call ' + self.ptype + '.new'
        else:
            return 'movq $0, ' + self.assignee

#for assigning constants to variables
class ASMConstant(ASMDeclare):
    def __init__(self, assignee, ptype, const):
        self.assignee = assignee
        self.ptype = ptype
        self.const = const
    def __str__(self):
        if self.ptype == 'string':
            return 'movq $' + ASMIndexer.strMap[self.const] + ', ' + self.assignee
        if self.ptype == 'int':
            return 'movq $' + str(self.const) + ', ' + self.assignee
        if self.ptype == 'bool':
            if self.const == 'true':
                return 'movq $1, ' + self.assignee
            else:
                return 'movq $0, ' + self.assignee

#"abstract" class for the control instructions
class ASMControl(ASMInstruction):
    pass

#move data onto the stack
class ASMPush(ASMControl):
    def __init__(self, reg):
        self.reg = reg
    def __str__(self):
        return 'pushq ' + self.reg

#move data off the stack and into a register
class ASMPop(ASMControl):
    def __init__(self, reg):
        self.reg = reg
    def __str__(self):
        return 'popq ' + self.reg

#ASM calls to functions
class ASMCall(ASMControl):
    #for linux calls, "integer" parameters passed in order; rdi, rsi, rdx, rcx, r8, r9, stack
    #paramorder = ['%rdi', '%rsi', '%rdx', '%rcx', '%r8', '%r9']
    def __init__(self, assignee, funcname, args=[]):
        self.assignee = assignee
        self.funcname = funcname
        self.args = args
    def expand(self):
        asm = []
        for i, arg in enumerate(self.args[:len(paramRegs)]):
            asm.append(ASMAssign(cRegMap[paramRegs[i]], arg))
        #push args onto stack in reverse order
        for arg in reversed(self.args[len(paramRegs):]):
            asm.append(ASMPush(arg))
        asm.append(self)
        #deallocate args
        if len(self.args) > len(paramRegs):
            lisize = '$'+str((len(self.args)-len(paramRegs)) * 8)
            asm.append(ASMOp(rsp, '+', [lisize, rsp]))
        return asm
    def __str__(self):
        #if function is in register or memory, use *
        if self.funcname in registers or ('(' in self.funcname and ')' in self.funcname):
            return 'call *' + self.funcname
        else:
            return 'call ' + self.funcname

#Jmp instruction
class ASMJmp(ASMControl):
    def __init__(self, label):
        self.label = label
    def __str__(self):
        return 'jmp ' + self.label

#label instruction
class ASMLabel(ASMControl):
    def __init__(self, name):
        self.name = name
    def __str__(self):
        return self.name + ':'

# Special instructions that pass info to the assembler
class ASMInfo(ASMControl):
    def __init__(self, name, *args):
        self.name = name
        self.args = args
    def __str__(self):
        return "." + self.name + " " + ', '.join(self.args)

#Return instruction
class ASMReturn(ASMControl):
    def __init__(self, retval):
        self.retval = retval
    def expand(self):
        asm = []
        if self.retval != cRegMap[retreg]:
            asm.append(ASMAssign(cRegMap[retreg], self.retval))
        asm.append(ASMMisc('leave'))
        asm.append(self)
        return asm
    def __str__(self):
        return 'ret'

#Bt instruction
class ASMBT(ASMControl):
    def __init__(self, cond, label, g=True, l=True, e=False):
        self.cond = cond
        self.label = label
        self.g = g
        self.l = l
        self.e = e
    def invert(self):
        self.g = not self.g
        self.l = not self.l
        self.e = not self.e
    def expand(self):
        return [ASMCmp('$1', self.cond, False, False), self]
    def __str__(self):
        condstr = ''
        condstr += 'g' if self.g else ''
        condstr += 'l' if self.l else ''
        condstr += 'e' if self.e else ''
        if condstr == 'gle':
            # completes to jmp
            condstr = 'mp'
        elif condstr == 'gl':
            condstr = 'ne'

        return 'j{} {}'.format(condstr, self.label)

class ASMBTypeEq(ASMInstruction):
    def __init__(self, obj, clstag, label):
        self.obj = obj
        self.clstag = clstag
        self.label = label
    def expand(self):
        asm = []
        # if obj is in memory pull it into register
        if self.obj not in registers:
            asm.append(ASMAssign('%rdx', self.obj))
            self.obj = '%rdx'
        # do cmp on obj class tag and self.clstag
        asm.append(ASMCmp('$'+self.clstag +'_vtable', '0('+self.obj+')'))
        # do conditional jump to self.label if cmp yields equal
        asm.append(ASMMisc('je', [self.label]))
        return asm
    def __str__(self):
        return ''

#catchall for instructions that have no strong association with category
class ASMMisc(ASMInstruction):
    def __init__(self, cmd, args=[]):
        self.cmd = cmd
        self.args = args
    def __str__(self):
        retval = self.cmd
        argstr = ', '.join(self.args)
        if argstr:
            retval += ' ' + argstr
        return retval
class ASMComment(ASMInstruction):
    def __init__(self, s):
        self.content = s
    def __str__(self):
        return '# ' + self.content
#end ASM class definitions


def offsetStr(off, reg):
    return str(off) + '(' + reg + ')'

#takes a control flow graph and mapping of virtual registers to colors
#returns list of x64 instructions as ASM* instances
def funcConvert(cfg, regMap):

    #if virtual register, return either register name or place in memory (if index too high)
    #if class attr or method arg, return memory location with appropriate offset
    #TODO review indexing of temporaries relative to rbp
    def realReg(operand):
        if isinstance(operand, TACRegister):
            vreg = operand.name
            if regMap[vreg] not in cRegMap:
                return offsetStr(-8*(regMap[vreg]-len(cRegMap)+1), rbp)
            return cRegMap[regMap[vreg]]
        elif isinstance(operand, TACClassAttr):
            vreg = operand.reg.name
            #NOTE to handle class attr reg (i.e. "self", or Int/Bool "val") being in memory (i.e. needing double memory lookup)
            # this helper method directly modifies asmlst! Need to review correctness
            if regMap[vreg] not in cRegMap:
                asmlst.append(ASMAssign('%rdx', offsetStr(-8*(regMap[vreg]-len(cRegMap)+1), rbp)))
                rreg = '%rdx'
            else:
                rreg = cRegMap[regMap[vreg]]
            return offsetStr(8 * ASMIndexer.attrOffset[operand.cname][operand.aname], rreg)
        elif isinstance(operand, TACMethodArg):
            ind = ASMIndexer.methOffset[operand.cname][operand.mname][operand.fname]
            if ind < len(paramRegs):
                return cRegMap[paramRegs[ind]]
            else:
                return offsetStr(8 * ((ind - len(paramRegs))+ 2), rbp)

    inslst = cfg.toList()

    preamble = []
    epilogue = []

    #function prologue
    preamble += [
        ASMPush(rbp),
        ASMAssign(rbp, rsp),
    ]

    # Allocate stack space for temporaries
    # TODO review number of spaces allocated
    stackmem = 8*(max(regMap.values()) - len(cRegMap) + 1)
    if stackmem > 0:
        preamble+=[
            ASMOp(rsp, '-', ['$'+str(stackmem), rsp])
        ]

    # Save non-parameter registers
    maxreg = min(max(regMap.values()), max(cRegMap.keys()))
    if maxreg > 0:
        for i in range(1, maxreg+1):
            if i not in paramRegs:
                preamble.append(ASMPush(cRegMap[i]))
                epilogue = [ASMPop(cRegMap[i])] + epilogue

    asmlst = []
    #make list of ASM instructions from TAC instructions
    for ins in inslst:
        if isinstance(ins, TACOp):
            if isinstance(ins, TACCompare):
                if ins.ptype == 'String':
                    if realReg(ins.assignee) != '%rax':
                        asmlst += [
                            ASMPush('%rax'),
                            ASMCall('%rax', 'String.cmp', [realReg(ins.op1), realReg(ins.op2)]),
                            ASMAssign(realReg(ins.assignee), '%rax'),
                            ASMPop('%rax'),
                            ASMOp(realReg(ins.assignee), ins.opcode, [realReg(ins.assignee), '$0'])
                        ]
                    else:
                        asmlst += [
                            ASMCall('%rax', 'String.cmp', [realReg(ins.op1), realReg(ins.op2)]),
                            ASMOp(realReg(ins.assignee), ins.opcode, [realReg(ins.assignee), '$0'])
                        ]
                elif ins.ptype == 'Object':
                    if realReg(ins.assignee) != '%rax':
                        asmlst += [
                            ASMPush('%rax'),
                            ASMCall('%rax', 'Object.cmp', [realReg(ins.op1), realReg(ins.op2)]),
                            ASMAssign(realReg(ins.assignee), '%rax'),
                            ASMPop('%rax'),
                            ASMOp(realReg(ins.assignee), ins.opcode, [realReg(ins.assignee), '$0'])
                        ]
                    else:
                        asmlst += [
                            ASMCall('%rax', 'Object.cmp', [realReg(ins.op1), realReg(ins.op2)]),
                            ASMOp(realReg(ins.assignee), ins.opcode, [realReg(ins.assignee), '$0'])
                        ]
                else: # Int/Bool
                    asmlst.append(ASMOp(realReg(ins.assignee), ins.opcode,
                                        [realReg(ins.op1), realReg(ins.op2)]))

            else:
                operands = [realReg(ins.op1), realReg(ins.op2)] \
                           if isinstance(ins, TACOp2) else [realReg(ins.op1)]
                asmlst.append(ASMOp(realReg(ins.assignee), ins.opcode, operands))
        elif isinstance(ins, TACAssign):
            asmlst.append(ASMAssign(realReg(ins.assignee), realReg(ins.assignor)))
        elif isinstance(ins, TACAllocate):
            asmlst.append(ASMAllocate(realReg(ins.assignee), ins.allop, ins.ptype))
        elif isinstance(ins, TACCall):
            funcname = ins.funcname
            if isinstance(ins.funcname, TACRegister):
                funcname = realReg(ins.funcname)
            asmlst.append(ASMCall(realReg(ins.assignee), funcname, [realReg(arg) for arg in ins.args]))
        elif isinstance(ins, TACLabel):
            asmlst.append(ASMLabel(ins.name))
        elif isinstance(ins, TACReturn):
            asmlst.append(ASMReturn(realReg(ins.retval)))
        elif isinstance(ins, TACJmp):
            asmlst.append(ASMJmp(ins.label))
        elif isinstance(ins, TACBT):
            asmlst.append(ASMBT(realReg(ins.cond), ins.label))
        elif isinstance(ins, TACConstant):
            asmlst.append(ASMConstant(realReg(ins.assignee), ins.ptype, ins.const))
        elif isinstance(ins, TACVTable):
            # Comment with method name
            asmlst.append(ASMComment(ins.cname + '.' + ins.mname))

            insreg = realReg(ins.assignee)
            objreg = realReg(ins.obj)
            if objreg not in registers:
                asmlst.append(ASMAssign('%rdx', objreg))
                objreg = '%rdx'
            asmlst += [
                # vtable addr -> rdx
                ASMAssign(insreg, offsetStr(0, objreg)),
                # method addr -> assignee
                ASMAssign(insreg, offsetStr(ASMIndexer.getvtableind(ins.cname, ins.mname), insreg))
            ]
        elif isinstance(ins, TACMalloc):
            nattrs = len(ASMIndexer.attrOffset[ins.cname])
            asmlst += [
                ASMCall('%rax', 'getmem', ['$' + str(8*(nattrs + 1))]),
                ASMAssign('0(%rax)', '$' + ins.cname + "_vtable"),
            ]
        elif isinstance(ins, TACBTypeEq):
            asmlst.append(ASMBTypeEq(realReg(ins.obj), ins.dtype, ins.label))
        elif isinstance(ins, TACError):
            asmlst += [
                ASMAssign('%rsi', '$' + str(ins.lineno)),
                ASMAssign('%rdi', '$'+ASMIndexer.strMap[ASMIndexer.errstrMap[ins.reason]]+'_l'),
                ASMMisc('call out_error')
            ]
        else:
            asmlst.append("UNHANDLED: "+ str(ins))

    #put preamble after start label, epilogue before return
    asmlst = [ASMInfo('globl', asmlst[0].name), ASMInfo('type',asmlst[0].name,  '@function')] + \
             asmlst[:1] + preamble + asmlst[1:-1] \
             + epilogue + asmlst[-1:] + [ASMInfo('size', asmlst[0].name, '.-'+asmlst[0].name)]

    #expand out instructions to full ASM
    explst = []
    for ins in asmlst:
        if hasattr(ins, 'expand'):
            explst += ins.expand()
        else:
            explst += [ins]

    # Remove useless mov instructions
    rmlist = []
    for i, ins in enumerate(explst):
        if isinstance(ins, ASMAssign) and ins.assignee == ins.assignor:
            rmlist.append(i)
    explst = [ins for i,ins in enumerate(explst) if i not in rmlist]

    return explst

def asmStr(asmlst):
    outbuf = ''
    for ins in asmlst:
        if not isinstance(ins, ASMLabel):
            outbuf += '\t'
        outbuf += str(ins) + '\n'
    return outbuf

def convert(taclist):
    methlist = []
    lastInd = 0
    for i in range(len(taclist)):
        # Split taclist on method labels
        if isinstance(taclist[i], TACLabel) and taclist[i].name[0] != '.':
            if i != 0:
                methlist.append(taclist[lastInd:i])
                lastInd = i
    methlist.append(taclist[lastInd:])

    # for m in methlist:
    #     for x in m:
    #         print x
    #     print '---'

    asmlist = []
    for meth in methlist:
        cfg = _constructCFG(meth)
        #print cfg
        #print '-----'
        #optCFG(cfg)
        #print cfg
        #print '-----'
        globalDeadRemove(cfg)
        #print cfg
        #print '-----'

        regmap = registerAllocate(cfg,len(cRegMap))

        asmlist += funcConvert(cfg, regmap)

    return asmlist

def readInternals():
    with open('internals.s.txt', 'rU') as inFile:
        return inFile.read()

if __name__ == '__main__':
    with open(sys.argv[1], 'U') as inFile:
        cfg = serializeTAC(inFile)
    #allocate 14 virtual registers - need coloring for more
    #regMap = registerAllocate(cfg)
    regMap = {}
    for i in range(14):
        regMap['t$'+str(i)] = i
    asmlst = funcConvert(cfg, regMap)
    outbuf = ''
    for asmins in asmlst:
        asminslst = asmins.expand()
        for asmsubins in asminslst:
            outbuf = outbuf + str(asmsubins) + '\n'
    print outbuf
